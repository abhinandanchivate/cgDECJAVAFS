package com.cg.emplmngt;

import java.util.Iterator;

import com.cg.emplmngt.dto.Employee;
import com.cg.emplmngt.service.EmployeeService;

public class Main {
// entry point for our execution.
	public static void main(String[] args) {
		
		EmployeeService employeeService = EmployeeService.getInstance();
		
	
		for(int i=1; i<=12;i++) {
			Employee employee = new Employee
					("AB00"+i,"abhinandan","chivate",123.0f,1);;
			
					System.out.println(employee);
					String result = employeeService.addEmployee(employee);
			
			System.out.println(result);
		}
		
		Employee[] employees = employeeService.getEmployees();
		
		for (Employee employee : employees) {
			
			if(employee!=null)
			
			System.out.println("employee record is"+employee);
		}
		
		
	}
}
