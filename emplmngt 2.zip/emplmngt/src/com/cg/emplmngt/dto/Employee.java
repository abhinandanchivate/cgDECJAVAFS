package com.cg.emplmngt.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee {

	/*
	 * 
	 * employeeId
	 * empFirstName
	 * empLastname
	 * empSalary
	 * deptId
	 * 
	 * the packages which are starting with java or 
	 *javax are the predefined packages from java
	 *
	 * */
	
	private String employeeId;// ref.===> will refer the
	//object
	private String empFirstName;// camel naming convention.
	private String empLastName;
	private float empSalary;
	private int deptId;
	}
