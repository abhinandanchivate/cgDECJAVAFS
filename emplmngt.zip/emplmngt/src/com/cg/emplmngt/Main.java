package com.cg.emplmngt;

import com.cg.emplmngt.dto.Employee;

public class Main {
// entry point for our execution.
	public static void main(String[] args) {
		
		Employee employee = new Employee();
		// Employee : user defined class
		// employee : local ref which will refer
		//the object
		// new : to create the object 
		//        @ the RT(run time)
		// Employee() : constructor
		// will initialize the object
		// object memory will be allocated 1st
		// then constructor will initialize
		// the object
		
		employee.setEmployeeId("AB001");
		employee.setEmpFirstName("abhi");
		employee.setEmpLastName("Chivate");
		employee.setDeptId(1);
		
		System.out.println(employee.getEmployeeId());
		System.out.println(employee.getEmpFirstName());
		
		
	}
}
