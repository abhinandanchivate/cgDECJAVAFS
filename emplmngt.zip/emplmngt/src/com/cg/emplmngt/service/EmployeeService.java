package com.cg.emplmngt.service;

import com.cg.emplmngt.dto.Employee;
import com.cg.emplmngt.repository.EmployeeRepository;

public class EmployeeService {

	// can we have singleton impl?
	
	private EmployeeRepository employeeRepository = EmployeeRepository.getInstance();
	
	public String addEmployee(Employee employee) {
		
		return employeeRepository.addEmployee(employee);
		
	}
	
	public Employee getEmployeeById(String employeeId) {
		return employeeRepository.getEmployeeById(employeeId);
	}
}
