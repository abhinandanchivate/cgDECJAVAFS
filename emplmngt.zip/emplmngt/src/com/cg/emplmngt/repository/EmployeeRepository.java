package com.cg.emplmngt.repository;

import java.util.Arrays;

import com.cg.emplmngt.dto.Employee;

public class EmployeeRepository {
	
	public static void main(String[] args) {
		EmployeeRepository employeeRepository = EmployeeRepository.getInstance();
		EmployeeRepository employeeRepository2 = EmployeeRepository.getInstance();
		EmployeeRepository employeeRepository3 = EmployeeRepository.getInstance();
		EmployeeRepository employeeRepository4 = EmployeeRepository.getInstance();
		
		
	}
	private EmployeeRepository() {
		
	}
	private static EmployeeRepository employeeRepository;// null copies : only one.
	
	
public static EmployeeRepository getInstance() {
	
	if(employeeRepository==null) {
		System.out.println("hello from if condition");
		employeeRepository = new EmployeeRepository();
		return employeeRepository;
	}
	return employeeRepository;
	
}
	
	private static int counter = -1;
	
	
	private Employee[] employees = new Employee[10];
	//private : inside the class
	// Employee[] : array declaration
	// employees : array of ref of type Employee
	// new : to allocate the memory @ the RT
	// Employee[10] : we will specify the size of the array
	
	public String addEmployee(Employee employee) {
		// to add employee object in the array.
		
		if(counter <employees.length) {
		employees[++counter] = employee;
		return "success";
		}
		else {
			// we reached to the last limit 
			// do we need to increase the array capacity ? 
			
			Employee[] temp = new Employee[employees.length * 2];
			
			// copy the content from employees to temp
			
			// 1. System class
			System.arraycopy(employees, 0, temp, 0, counter);
			// source : from where u want to copy the array content
			// srcstartPOS 
			// dest
			// deststartpos
			// how many
			
			employees  = temp;
			
			// 2 Arrays : assignment for you (you have to tell me the best with respect to performance out of system.arrayscopy and
			//Arrays.copyof
		
			return "success";
			
			
			
		}
		
	}
	
	// updating the employee details
	public String updateEmployee(Employee employee, String employeeId) {
		return null;
	}
	// based on the id it should delete the employee details.
	public String deleteEmployeeById(String employeeId) {
		return null;
	}
	// based on the id it should return the employee object/ detials.
	public Employee getEmployeeById(String employeeid) {
		
		for (Employee employee : employees) {
			if(employee != null && employee.getEmployeeId().equals(employeeid)) {
				return employee;
			}
		}
		return null;
	}
	// should return all the records.
	public Employee[] getEmployees() {
		return null;
	}
	

}
